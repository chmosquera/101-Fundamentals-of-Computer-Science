#Name: Chanelle Mosquera
#Section: 101-16
#Description: Boolean Logic
#Instructor: S. Einakian
#Due date: Jan. 21, 2016


def is_even(integer):
   return (integer % 2) == 0

def in_an_interval(number):
   return 2 <= number < 9 or 47 < number < 92 or 12 < number <= 19 or 101 <= number <= 103


